## Load packages
library(SGAT)
library(BAStag)
library(raster)
library(maptools)
source("C:/Users/jaimiec/Dropbox/Grey_petrel_GLS/Master code/colours.r")
setwd("C:/Users/jaimiec/Dropbox/Grey_petrel_GLS/Gough_GreyPetrel_GLS/GREPE_7A05418_08042016_GOUGH/")

## Reset
d.lig <- d.act <- NULL

## Tag details
## Set the tag id and the base filename for data files
tag <- "5418"
tagdata <- "GREPE_7A05418_08042016_GOUGH_000"

## Solar configuration
## Set the zenith angle and light threshold that define twilight, and
## the hour offset for the y axis of plots.
### Line = threshold light
### Zenith is where they start to go up
### CHANGE THESE FOR EACH TAG
zenith <- 95
threshold <- 4
dt <- 300
offset <- 14

## Model Parameters
alpha <- c(2.2,1.0)
beta <- c(2.8, 0.12) ## parameters of the speed model

## Locations
## Create a matrix of any known locations
burrow <- c(-9.9353,-40.3186)
locations <- matrix(c(burrow),1,2,byrow=T)

## Import the light data and display it as an image
d.lig <- readLig(paste0(tagdata,".lig"))
lightImage(d.lig,offset=offset)

## Crop any erroneous data
## Cropping data that is listed as ERROR during compression and downloading
sort(unique(d.lig$Valid))
d.lig <- d.lig[d.lig$Valid=="ok",]

#Adjust timestamp to negate the effect of incorrectly entered START TIME
#Know from where?
# x <- -0.1
# d.lig$Date <- d.lig$Date+x*60*60
# print(paste("Difference =", x*60, "mins"))

## How many days of data?
length(sort(unique(as.Date(d.lig$Date))))

## Import the activity data and display it as an image
# d.act <- readAct(paste0(tagdata,".act"))
# tsimage(d.act$Date,d.act$Activity,offset=offset,col=grey(seq(0,1,length=256)))

## Import the temperature data
d.tem <- readTem2(paste0(tagdata,".tem"), d.lig)
## Check for temperature data
any(!is.na(d.tem$Temp))

## Check calibration
## Extract calibration segment as first x days of logging
#d.calib <- subset(d.lig,Date < min(Date)+6*24*60*60 & Date > min(Date)+0*24*60*60)
## OR extract a specific date range for calibration
d.calib <- subset(d.lig, Date > as.POSIXct("2015-02-17", "GMT") & Date < as.POSIXct("2015-03-02", "GMT"))
lightImage(d.calib,offset=offset)
days <- seq(as.POSIXct("2015-02-17", "GMT"), as.POSIXct("2015-03-02", "GMT"), 24 * 60 * 60) #start and end calibration dates
sr <- sunrise(days, locations[,1], locations[,2])
ss <- sunset(days, locations[,1], locations[,2])
## Lines represent theoretical sunset and sunrise times for lat/lon of calibration location
tsimageLines(sr, offset = offset, lwd = 2, col = "dodgerblue")
tsimageLines(ss, offset = offset, lwd = 2, col = "firebrick")

## Get the zenith and threshold from xy plot
lightImage(d.calib,offset=offset)
thresholdCalibrate(d.calib,locations[1,1],locations[1,2],
                   xlim=c(80,100),ylim=c(0,70),pch=16)
abline(h=threshold,v=zenith)

## Deployment date
d.lig <- d.lig[d.lig$Date>as.POSIXct("2015-03-25"),]
## Retrieval date
d.lig <- d.lig[d.lig$Date<as.POSIXct("2016-03-31"),]
lightImage(d.lig,offset=offset)

## Interactive processing
## The process has 4 stages
##
## 1. The subset of data is selected (left click=start, right
## click=end)
## 2. Twilight search (left click = search point, right click =
## prevent search)
## 3. Insert missing twilights (left click = sunset, right click =
## sunrise, 0-9 sets markers)
## 4. Edit individual twilight (left click = select time, right click
## = delete, 0-9 sets markers)
##
## In stages 3 and 4, setting a marker with a known location sets the
## twilight time to the time of twilight for that location.

## Process light data
twl <- preprocessLight(d.lig,threshold,offset=offset,zenith=zenith,
                       fixed=locations)
head(twl)

## Investigate twilights less than 3 hrs apart
which(diff(as.numeric(twl$Twilight)) < 3*60*60)
# twl <- twl[-which(diff(as.numeric(twl$Twilight)) < 3*60*60),]

# Investigate rise/set out of sequence
which(diff(twl$Rise)==0)


## Store twilights
# save(twl,file=paste0(tag,"twl.RData"))
load(paste0(tag, "twl.Rdata"))

## Remove deleted
twl <- twl[!twl$Deleted,]


## For difficult cases, we can restart an edit in map mode to
## interactively identify problem twilights
##
##
## ## Define map
## load(paste0(tag,"twl.RData"))
## library(maptools)
## data(wrld_simpl)
## plotMap <- function(xlim,ylim) {
##   plot.new()
##   plot.window(xlim,ylim)
##   plot(wrld_simpl,add=TRUE,col="grey90")
##   if(max(xlim) > 180) plot(elide(wrld_simpl,shift=c(360,0)),add=TRUE,col="grey90")
##   if(min(xlim) < -180) plot(elide(wrld_simpl,shift=c(-360,0)),add=TRUE,col="grey90")
## }
##
## ## Process light data
## twl <- preprocessLight(d.lig,threshold,offset=offset,zenith=zenith,
##                        fixed=locations,
##                        map=TRUE,plotMap=plotMap,
##                        twilights=twl,stage=4)
## head(twl)




## Adjust for the pecularities of the BAS tag.  The twilight times
## inserted by process.light are exact, so we hold those fixed.
fixed <- twl$Marker %in% seq_len(NROW(locations))
twl <- twilightAdjust(twl,dt,fixed=fixed)

## Compute initial path with a simplistic threshold method
path <- thresholdPath(twl$Twilight,twl$Rise,zenith=zenith)

## Set marked points
for(k in seq_len(nrow(locations))) {
  path$x[twl$Marker==k,1] <- locations[k,1]
  path$x[twl$Marker==k,2] <- locations[k,2]
}


## Show the estimate path against a world map
library(maptools)
data(wrld_simpl)
plot(path$x,type="n")
plot(wrld_simpl,add=T,col=map1.col,border=map2.col)
plot(elide(wrld_simpl,shift=c(360,0)),add=T,col=map1.col,border=map2.col)
lines(path$x,col=trk.col)
points(path$x,pch=16,cex=0.5,col=trk.col)

## Add filtered SST
source("C:/Users/jaimiec/Dropbox/Grey_petrel_GLS/Master code/SST.r")

## This function which SST values are unreliable by computing the
## median SST for the interval spanning a number of points around each
## point, and then marking points that lie limit degrees above the
## median as suspect.
del <- sstFilter(d.tem,before=3*24,after=3*24,limit=4)

## The set of observations marked for deletion by sstFilter can be
## interactively edited with the selectData function.
del <- selectData(d.tem$Date,d.tem$Temp,deleted=del,pch=16)

## This function searches the SST time series and returns mean SST in
## the interval surrounding each twilight, or NA of there are none.
twl$SST <- twilightData(d.tem$Date[!del],d.tem$Temp[!del],twl$Twilight,before=4,after=4)

## Store twilights with SST
save(twl,file=paste0(tag,"twlSST.RData"))

## Write configuration files

## The final stage is to output all the information needed to analyse
## the preprocessed twilights.  Three files are produced
##
## path.csv     - the initial path
## twl.csv      - the estimated twilights
## config.r     - an R script to set parameters

## Write path and twilights
colnames(path$x) <- c("lon","lat")
write.csv(cbind.data.frame(time=path$time,path$x),paste0(tag,"path.csv"),row.names=FALSE)
write.csv(twl,"twilight.csv",row.names=FALSE)


## Estimate bounding box from the best estimated path
xlim <- c(floor(min(path$x[,1]))-10,ceiling(max(path$x[,1]))+10)
ylim <- c(max(floor(min(path$x[,2]))-10,-85),min(ceiling(max(path$x[,2]))+10,85))


## Write configuration data
cat("## Configuration\n",
    "tag <- ", deparse(tag),"\n",
    "tagdata <- ", deparse(tagdata),"\n",
    "alpha <- ", deparse(alpha),"\n",
    "beta <- ", deparse(beta),"\n",
    "offset <- ",offset,"\n",
    "threshold <- ",threshold,"\n",
    "zenith <- ", zenith,"\n",
    "fixed.locations <- ",deparse(locations),"\n",
    "xlim <- ", deparse(xlim),"\n",
    "ylim <- ", deparse(ylim),"\n",
    file="config.r",sep="")

