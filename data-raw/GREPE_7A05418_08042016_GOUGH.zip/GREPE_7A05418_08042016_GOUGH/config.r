## Configuration
tag <- "5418"
tagdata <- "GREPE_7A05418_08042016_GOUGH_000"
alpha <- c(1, 0.3)
beta <- c(2.8, 0.12)
offset <- 14
threshold <- 4
zenith <- 95
fixed.locations <- structure(c(-9.9353, -40.3186), .Dim = 1:2)
xlim <- c(-70, 15)
ylim <- c(-85, 17)
